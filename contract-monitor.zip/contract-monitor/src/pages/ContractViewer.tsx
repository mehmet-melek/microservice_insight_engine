import { useState } from 'react';
import {
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Typography,
  Container,
  List,
  ListItemText,
  Paper,
  Box,
  AppBar,
  Toolbar,
  Collapse,
  ListItemIcon,
  ListItemButton,
  useMediaQuery,
  Divider
} from '@mui/material';
import type { SelectChangeEvent } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import { useQuery } from '@tanstack/react-query';
import { bitbucketService } from '../services/bitbucketService';
import FolderIcon from '@mui/icons-material/Folder';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import FolderOffIcon from '@mui/icons-material/FolderOff';
import InsertDriveFileOutlinedIcon from '@mui/icons-material/InsertDriveFileOutlined';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { prism } from 'react-syntax-highlighter/dist/esm/styles/prism';

const CONTRACT_PATH = 'sIc/test/resources/contract';

interface FileNode {
  name: string;
  type: 'FILE' | 'DIRECTORY';
  path: string;
  children?: FileNode[];
}

export default function ContractViewer() {
  const [selectedProject, setSelectedProject] = useState<string>('');
  const [selectedRepo, setSelectedRepo] = useState<string>('');
  const [selectedFile, setSelectedFile] = useState<string>('');
  const [expandedDirs, setExpandedDirs] = useState<Set<string>>(new Set());
  const [activeTab, setActiveTab] = useState<'info' | 'content'>('info');
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));

  const { data: projects, isLoading: isLoadingProjects } = useQuery({
    queryKey: ['projects'],
    queryFn: bitbucketService.getProjects,
  });

  const { data: repositories, isLoading: isLoadingRepos } = useQuery({
    queryKey: ['repositories', selectedProject],
    queryFn: () => bitbucketService.getRepositories(selectedProject),
    enabled: !!selectedProject,
  });

  const { data: contractFiles, isLoading: isLoadingFiles } = useQuery({
    queryKey: ['contractFiles', selectedProject, selectedRepo],
    queryFn: async () => {
      const files: FileNode[] = [];
      const processNode = async (node: any, currentPath: string = ''): Promise<FileNode> => {
        const filePath = currentPath ? `${currentPath}/${node.path.name}` : node.path.name;
        if (node.type === 'FILE') {
          return {
            name: node.path.name,
            type: 'FILE',
            path: filePath
          };
        } else if (node.type === 'DIRECTORY') {
          try {
            const response = await bitbucketService.getDirectoryContents(
              selectedProject,
              selectedRepo,
              `${CONTRACT_PATH}/${filePath}`
            );
            const children: FileNode[] = [];
            if (response && response.length > 0) {
              for (const child of response) {
                const childNode = await processNode(child, filePath);
                children.push(childNode);
              }
            }
            return {
              name: node.path.name,
              type: 'DIRECTORY',
              path: filePath,
              children
            };
          } catch {
            return {
              name: node.path.name,
              type: 'DIRECTORY',
              path: filePath,
              children: []
            };
          }
        }
        return {
          name: node.path.name,
          type: 'FILE',
          path: filePath
        };
      };
      try {
        const response = await bitbucketService.getDirectoryContents(
          selectedProject,
          selectedRepo,
          CONTRACT_PATH
        );
        if (response && response.length > 0) {
          for (const node of response) {
            const processedNode = await processNode(node);
            files.push(processedNode);
          }
        }
        return files;
      } catch {
        return [];
      }
    },
    enabled: !!selectedProject && !!selectedRepo,
  });

  const { data: fileContent, isLoading: isLoadingContent } = useQuery({
    queryKey: ['fileContent', selectedProject, selectedRepo, selectedFile],
    queryFn: () => bitbucketService.getFileContent(selectedProject, selectedRepo, `${CONTRACT_PATH}/${selectedFile}`),
    enabled: !!selectedProject && !!selectedRepo && !!selectedFile,
  });

  const { data: pomInfo, isLoading: isLoadingPomInfo } = useQuery({
    queryKey: ['pomInfo', selectedProject, selectedRepo],
    queryFn: () => bitbucketService.getPomInfo(selectedProject, selectedRepo),
    enabled: !!contractFiles && contractFiles.length > 0,
  });

  const handleProjectChange = (event: SelectChangeEvent) => {
    setSelectedProject(event.target.value);
    setSelectedRepo('');
    setSelectedFile('');
    setExpandedDirs(new Set());
  };

  const handleRepoChange = (event: SelectChangeEvent) => {
    setSelectedRepo(event.target.value);
    setSelectedFile('');
    setExpandedDirs(new Set());
  };

  const handleFileClick = (path: string) => {
    setSelectedFile(path);
  };

  const handleDirectoryClick = (path: string) => {
    setExpandedDirs(prev => {
      const newSet = new Set(prev);
      if (newSet.has(path)) {
        newSet.delete(path);
      } else {
        newSet.add(path);
      }
      return newSet;
    });
  };

  const renderFileTree = (nodes: FileNode[], level: number = 0) => {
    return nodes.map((node) => {
      const isDir = node.type === 'DIRECTORY';
      const isOpen = expandedDirs.has(node.path);
      const iconColor = '#1976d2';
      return (
        <Box key={node.path}>
          <ListItemButton
            onClick={() => isDir ? handleDirectoryClick(node.path) : handleFileClick(node.path)}
            selected={node.path === selectedFile}
            sx={{
              pl: `calc(24px + ${level * 20}px)`,
              pr: 3,
              mb: 0.5,
              borderRadius: 2.5,
              background: node.path === selectedFile ? '#e8f0fe' : (isDir && isOpen ? '#f5f7fa' : 'transparent'),
              fontWeight: 400,
              color: '#222',
              minHeight: 44,
              display: 'flex',
              alignItems: 'center',
              '&:hover': {
                background: isDir ? '#f5f7fa' : '#f0f4ff',
              },
              gap: 1,
              boxSizing: 'border-box',
              width: 'calc(100%)',
              maxWidth: '100%',
              mr: '12px',
            }}
          >
            {isDir ? (
              isOpen ? (
                <KeyboardArrowDownIcon sx={{ color: iconColor, fontSize: 22, mr: 1 }} />
              ) : (
                <KeyboardArrowRightIcon sx={{ color: iconColor, fontSize: 22, mr: 1 }} />
              )
            ) : (
              <InsertDriveFileIcon sx={{ color: iconColor, fontSize: 22, mr: 1 }} />
            )}
            <ListItemText primary={node.name} primaryTypographyProps={{ fontWeight: 400, fontSize: 15, color: '#222' }} />
          </ListItemButton>
          {isDir && node.children && (
            <Collapse in={isOpen} timeout="auto" unmountOnExit>
              <List component="div" disablePadding>
                {renderFileTree(node.children, level + 1)}
              </List>
            </Collapse>
          )}
        </Box>
      );
    });
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', background: '#fff', width: '100vw', maxWidth: 'none', position: 'relative' }}>
      <AppBar position="static" sx={{ backgroundColor: '#4B6CFF', boxShadow: 'none', height: 64, justifyContent: 'center', width: '100vw', maxWidth: 'none', zIndex: 2 }}>
        <Toolbar sx={{ minHeight: 64, width: '100%', maxWidth: 'none', mx: 'auto', px: 4 }}>
          <Typography variant="h6" component="div" sx={{ fontWeight: 600, fontSize: 24, width: '100%' }}>
            Contract Viewer
          </Typography>
        </Toolbar>
      </AppBar>
      {/* Dikey çizgi */}
      <Box sx={{ flex: 1, display: 'flex', flexDirection: isMobile ? 'column' : 'row', p: isMobile ? 0 : 1, gap: 0, background: '#fff', width: '100vw', maxWidth: 'none', position: 'relative', zIndex: 2 }}>
        {/* Sidebar */}
        <Box
          sx={{
            width: isMobile ? '100%' : 400,
            minWidth: isMobile ? '100%' : 400,
            maxWidth: isMobile ? '100%' : 400,
            display: 'flex',
            flexDirection: 'column',
            gap: 3,
            background: '#fff',
            py: isMobile ? 2 : 0,
            minHeight: isMobile ? 'auto' : 'calc(100vh - 64px)',
          }}
        >
          <Paper elevation={0} sx={{ p: 3, borderRadius: 3, flex: 1, minHeight: 200, display: 'flex', flexDirection: 'column', background: '#fff', boxShadow: 'none', mt: 3 }}>
            <FormControl fullWidth sx={{ mb: 2 }}>
              <InputLabel sx={{ borderRadius: 2, background: '#fff' }}>Project</InputLabel>
              <Select
                value={selectedProject}
                label="Project"
                onChange={handleProjectChange}
                disabled={isLoadingProjects}
                sx={{ borderRadius: 2, background: '#fff' }}
                MenuProps={{ PaperProps: { sx: { borderRadius: 2 } } }}
              >
                {projects?.map((project: { key: string; name: string }) => (
                  <MenuItem key={project.key} value={project.key} sx={{ borderRadius: 2 }}>
                    {project.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl fullWidth sx={{ mb: 2 }}>
              <InputLabel sx={{ borderRadius: 2, background: '#fff' }}>Repository</InputLabel>
              <Select
                value={selectedRepo}
                label="Repository"
                onChange={handleRepoChange}
                disabled={isLoadingRepos || !selectedProject}
                sx={{ borderRadius: 2, background: '#fff' }}
                MenuProps={{ PaperProps: { sx: { borderRadius: 2 } } }}
              >
                {repositories?.map((repo: { name: string; slug: string }) => (
                  <MenuItem key={repo.slug} value={repo.slug} sx={{ borderRadius: 2 }}>
                    {repo.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            {/* Contract Files başlığı ve içerik */}
            {!selectedProject ? (
              <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', mt: 4, mb: 2 }}>
                <InfoOutlinedIcon sx={{ fontSize: 40, color: '#90a4ae', mb: 1 }} />
                <Typography variant="subtitle1" sx={{ color: '#555', fontWeight: 500, mb: 0.5 }}>
                  Please select a project
                </Typography>
                <Typography variant="body2" sx={{ color: '#888' }}>
                  To view contract files, select a project from the list above.
                </Typography>
              </Box>
            ) : selectedRepo && (contractFiles && contractFiles.length > 0) ? (
              <>
                <Typography variant="subtitle2" sx={{ fontWeight: 500, mb: 1, fontSize: 15, color: '#222', letterSpacing: 0.1, mt: 3 }}>
                  Contract Files {isLoadingPomInfo && '(Loading contract info...)'}
                </Typography>
                <List disablePadding>
                  {contractFiles && renderFileTree(contractFiles)}
                </List>
              </>
            ) : selectedRepo && contractFiles && contractFiles.length === 0 ? (
              <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', mt: 4, mb: 2 }}>
                <FolderOffIcon sx={{ fontSize: 40, color: '#90a4ae', mb: 1 }} />
                <Typography variant="subtitle1" sx={{ color: '#555', fontWeight: 500, mb: 0.5 }}>
                  No contract files found
                </Typography>
                <Typography variant="body2" sx={{ color: '#888' }}>
                  There are no contract files in the selected repository.
                </Typography>
              </Box>
            ) : null}
          </Paper>
        </Box>
        {/* Dikey çizgi */}
        {!isMobile && (
          <Box sx={{ width: '1.5px', bgcolor: '#E0E3E7', minHeight: 'calc(100vh - 64px)', alignSelf: 'stretch' }} />
        )}
        {/* Content */}
        <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0, background: '#fff', minHeight: isMobile ? 'auto' : 'calc(100vh - 64px)' }}>
          <Paper elevation={0} sx={{ p: 4, borderRadius: 3, minHeight: 300, flex: 1, display: 'flex', flexDirection: 'column', background: '#fff', boxShadow: 'none' }}>
            {/* Sekmeli başlıklar */}
            <Box sx={{ display: 'flex', gap: 4, mb: 0, flexWrap: 'wrap', borderBottom: '1.5px solid #E0E3E7', position: 'relative' }}>
              <Box
                sx={{
                  px: 2,
                  pb: 1.5,
                  cursor: 'pointer',
                  fontWeight: activeTab === 'info' ? 700 : 500,
                  color: activeTab === 'info' ? '#2563eb' : '#222',
                  fontSize: 18,
                  background: 'none',
                  outline: 'none',
                  border: 'none',
                  boxShadow: 'none',
                  transition: 'color 0.2s',
                  position: 'relative',
                  '&:focus': { outline: 'none', border: 'none', boxShadow: 'none' },
                  '&:active': { outline: 'none', border: 'none', boxShadow: 'none' },
                }}
                component="button"
                onClick={() => setActiveTab('info')}
                tabIndex={0}
              >
                Contract Info
                {activeTab === 'info' && (
                  <Box sx={{ position: 'absolute', left: 0, right: 0, bottom: -2, height: 3, bgcolor: '#2563eb', borderRadius: 2 }} />
                )}
              </Box>
              <Box
                sx={{
                  px: 2,
                  pb: 1.5,
                  cursor: 'pointer',
                  fontWeight: activeTab === 'content' ? 700 : 500,
                  color: activeTab === 'content' ? '#2563eb' : '#222',
                  fontSize: 18,
                  background: 'none',
                  outline: 'none',
                  border: 'none',
                  boxShadow: 'none',
                  transition: 'color 0.2s',
                  position: 'relative',
                  '&:focus': { outline: 'none', border: 'none', boxShadow: 'none' },
                  '&:active': { outline: 'none', border: 'none', boxShadow: 'none' },
                }}
                component="button"
                onClick={() => setActiveTab('content')}
                tabIndex={0}
              >
                Contract Content
                {activeTab === 'content' && (
                  <Box sx={{ position: 'absolute', left: 0, right: 0, bottom: -2, height: 3, bgcolor: '#2563eb', borderRadius: 2 }} />
                )}
              </Box>
            </Box>
            {/* Sekme içerikleri */}
            <Box sx={{ flex: 1, mt: 3, display: activeTab === 'info' ? 'block' : 'none' }}>
              {/* Buraya contract info içeriği eklenebilir */}
              {!selectedFile ? (
                <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
                  <InsertDriveFileOutlinedIcon sx={{ fontSize: 48, color: '#90a4ae', mb: 1 }} />
                  <Typography variant="subtitle1" sx={{ color: '#555', fontWeight: 500, mb: 0.5 }}>
                    No contract file selected
                  </Typography>
                  <Typography variant="body2" sx={{ color: '#888' }}>
                    Please select a contract file from the list on the left to view its details.
                  </Typography>
                </Box>
              ) : isLoadingPomInfo ? (
                <Typography>Loading contract information...</Typography>
              ) : pomInfo ? (
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                  {/* Provider Information */}
                  <Box sx={{ borderBottom: '1px solid #eee', pb: 3 }}>
                    <Typography variant="h6" sx={{ fontSize: 18, fontWeight: 600, mb: 2 }}>
                      Provider Information
                    </Typography>
                    <Box sx={{ display: 'grid', gridTemplateColumns: 'auto 1fr', gap: 2 }}>
                      <Typography variant="subtitle2" sx={{ color: '#666', fontWeight: 500 }}>Group ID:</Typography>
                      <Typography sx={{ fontFamily: 'monospace', bgcolor: '#f5f5f5', p: 1, borderRadius: 1 }}>
                        {pomInfo.groupId}
                      </Typography>
                      <Typography variant="subtitle2" sx={{ color: '#666', fontWeight: 500 }}>Artifact ID (with stubs):</Typography>
                      <Typography sx={{ fontFamily: 'monospace', bgcolor: '#f5f5f5', p: 1, borderRadius: 1 }}>
                        {pomInfo.artifactId}-stubs
                      </Typography>
                    </Box>
                  </Box>
                  
                  {/* Integration Guide */}
                  <Box>
                    <Typography variant="h6" sx={{ fontSize: 18, fontWeight: 600, mb: 2 }}>
                      Integration Guide
                    </Typography>
                    <Typography variant="body2" sx={{ mb: 3, color: '#444', lineHeight: 1.6 }}>
                      Bu rehber, <span style={{ fontFamily: 'monospace', fontWeight: 500 }}>{pomInfo.groupId}:{pomInfo.artifactId}-stubs</span> provider'ına ait stub JAR'ını projenize entegre ederek, 
                      HTTP istemciniz aracılığıyla stub sunucusuna nasıl istek yapabileceğinizi ve provider servisinin contract'larına 
                      uygun yanıtlar alarak entegrasyon testlerinizi nasıl gerçekleştirebileceğinizi adım adım açıklamaktadır.
                    </Typography>
                    
                    {/* Step 1 */}
                    <Typography variant="subtitle1" sx={{ fontSize: 16, fontWeight: 600, color: '#333', mb: 1, mt: 2 }}>
                      1. Gerekli Bağımlılıkları Ekleme
                    </Typography>
                    <Typography variant="body2" sx={{ mb: 1, color: '#555' }}>
                      Projenizin <code>pom.xml</code> dosyasına aşağıdaki bağımlılıkları ekleyin:
                    </Typography>
                    <Box sx={{ mb: 3, borderRadius: 2, overflow: 'hidden' }}>
                      <SyntaxHighlighter
                        language="xml"
                        style={prism}
                        customStyle={{
                          margin: 0,
                          padding: '16px',
                          borderRadius: '8px',
                          fontSize: 13,
                        }}
                      >
{`<dependency>
    <groupId>${pomInfo.groupId}</groupId>
    <artifactId>${pomInfo.artifactId}-stubs</artifactId>
    <version>\${stub.version}</version>
    <scope>test</scope>
</dependency>

<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-contract-stub-runner</artifactId>
    <scope>test</scope>
</dependency>

<dependencyManagement>
    <dependencies>
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-dependencies</artifactId>
            <version>\${spring-cloud.version}</version>
            <type>pom</type>
            <scope>import</scope>
        </dependency>
    </dependencies>
</dependencyManagement>`}
                      </SyntaxHighlighter>
                    </Box>
                    
                    {/* Step 2 - JUnit 5 */}
                    <Typography variant="subtitle1" sx={{ fontSize: 16, fontWeight: 600, color: '#333', mb: 1, mt: 3 }}>
                      2. Test Sınıflarında Stub Runner'ı Yapılandırma
                    </Typography>
                    
                    <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1, mt: 2 }}>
                      JUnit 5 ile Kullanım
                    </Typography>
                    <Typography variant="body2" sx={{ mb: 1, color: '#555' }}>
                      JUnit 5 ile Spring Cloud Contract Stub Runner'ı yapılandırmak için:
                    </Typography>
                    <Box sx={{ mb: 3, borderRadius: 2, overflow: 'hidden' }}>
                      <SyntaxHighlighter
                        language="java"
                        style={prism}
                        customStyle={{
                          margin: 0,
                          padding: '16px',
                          borderRadius: '8px',
                          fontSize: 13,
                        }}
                      >
{`@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@AutoConfigureStubRunner(
    ids = {"${pomInfo.groupId}:${pomInfo.artifactId}-stubs:+:stubs:8081"},
    // '+' ile en son versiyonu kullanabilir veya belirli bir versiyon belirtebilirsiniz
    stubsMode = StubRunnerProperties.StubsMode.CLASSPATH
)
public class ConsumerServiceTest {

    @Autowired
    private RestTemplate restTemplate;

    private String providerBaseUrl = "http://localhost:8081";

    @Test
    public void shouldFetchDataFromStubbedProvider() {
        // Örnek: Provider'dan veri çekme
        ResponseEntity<String> response = restTemplate.getForEntity(
            providerBaseUrl + "/api/resource/123", String.class);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        // Contract'ta tanımlanan response body'sini doğrulama
    }
}`}
                      </SyntaxHighlighter>
                    </Box>

                    {/* JUnit 4 Example */}
                    <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1, mt: 3 }}>
                      JUnit 4 ile Kullanım
                    </Typography>
                    <Typography variant="body2" sx={{ mb: 1, color: '#555' }}>
                      JUnit 4 kullanan projeler için StubRunnerRule ile yapılandırma:
                    </Typography>
                    <Box sx={{ mb: 3, borderRadius: 2, overflow: 'hidden' }}>
                      <SyntaxHighlighter
                        language="java"
                        style={prism}
                        customStyle={{
                          margin: 0,
                          padding: '16px',
                          borderRadius: '8px',
                          fontSize: 13,
                        }}
                      >
{`@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class ConsumerServiceJUnit4Test {

    @Rule
    public StubRunnerRule stubRunnerRule = new StubRunnerRule()
        .downloadStub("${pomInfo.groupId}", "${pomInfo.artifactId}-stubs", "+", "stubs")
        .withPort(8081)
        .stubsMode(StubRunnerProperties.StubsMode.CLASSPATH);

    @Autowired
    private RestTemplate restTemplate;

    @Test
    public void shouldFetchDataFromStubbedProvider() {
        // Port numarasını dinamik olarak da alabilirsiniz
        // int port = stubRunnerRule.findStubUrl("${pomInfo.artifactId}-stubs").getPort();
        String providerBaseUrl = "http://localhost:8081";
        
        // Test kodunuz
        ResponseEntity<String> response = restTemplate.getForEntity(
            providerBaseUrl + "/api/resource/123", String.class);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }
}`}
                      </SyntaxHighlighter>
                    </Box>
                    
                    {/* Usage Notes */}
                    <Box sx={{ mt: 3, bgcolor: '#f0f7ff', p: 3, borderRadius: 2, borderLeft: '4px solid #1976d2' }}>
                      <Typography variant="subtitle2" sx={{ color: '#1e3a8a', fontWeight: 600, mb: 1 }}>
                        Entegrasyon Testi Avantajları
                      </Typography>
                      <Typography variant="body2" sx={{ color: '#333', lineHeight: 1.7 }}>
                        Bu yaklaşımla yapılan entegrasyon testlerinin avantajları:
                        
                        <ul style={{ marginTop: '8px' }}>
                          <li>Gerçek servis çalıştırmadan provider ile entegrasyonu test edebilirsiniz</li>
                          <li>Provider'ın contract'ları değiştiğinde testleriniz otomatik olarak bu değişiklikleri yakalar</li>
                          <li>CI/CD pipeline'ınızda güvenilir ve hızlı testler çalıştırabilirsiniz</li>
                          <li>Provider geliştirme ekibiyle aynı kontratlar üzerinden çalışarak uyumluluk sorunlarını önlersiniz</li>
                        </ul>
                      </Typography>
                    </Box>
                  </Box>
                </Box>
              ) : (
                <Typography color="text.secondary">Unable to load contract information.</Typography>
              )}
            </Box>
            <Box sx={{ flex: 1, mt: 3, display: activeTab === 'content' ? 'block' : 'none' }}>
              {!selectedFile ? (
                <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
                  <InsertDriveFileOutlinedIcon sx={{ fontSize: 48, color: '#90a4ae', mb: 1 }} />
                  <Typography variant="subtitle1" sx={{ color: '#555', fontWeight: 500, mb: 0.5 }}>
                    No contract file selected
                  </Typography>
                  <Typography variant="body2" sx={{ color: '#888' }}>
                    Please select a contract file from the list on the left to view its content.
                  </Typography>
                </Box>
              ) : isLoadingContent ? (
                <Typography>Loading...</Typography>
              ) : fileContent ? (
                <Box
                  sx={{
                    backgroundColor: '#f5f5f5',
                    padding: 2,
                    borderRadius: 2,
                    margin: 0,
                    fontSize: 15,
                    flex: 1,
                    overflow: 'auto',
                  }}
                >
                  <SyntaxHighlighter
                    language={selectedFile.endsWith('.groovy') ? 'groovy' : (selectedFile.endsWith('.yaml') || selectedFile.endsWith('.yml') ? 'yaml' : 'text')}
                    style={prism}
                    customStyle={{
                      background: 'transparent',
                      fontSize: 13,
                      margin: 0,
                      padding: 0,
                      color: '#222',
                      fontFamily: 'Fira Mono, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace',
                      fontWeight: 400,
                      lineHeight: 1.7,
                    }}
                    showLineNumbers={true}
                  >
                    {fileContent}
                  </SyntaxHighlighter>
                </Box>
              ) : null}
            </Box>
          </Paper>
        </Box>
      </Box>
    </Box>
  );
} 