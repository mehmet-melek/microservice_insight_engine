import axios from 'axios';

// Configuration parameters
export const CONFIG = {
  BASE_URL: 'https://b28285a9-fa60-4726-9dee-bb7b1c929816.mock.pstmn.io',
  DEFAULT_BRANCH: 'dev',
  CONTRACT_PATH: 'sIc/test/resources/contract',
  POM_PATH: 'sIc/pom.xml',
  DEFAULT_LIMIT: 1000
};

const api = axios.create({
  baseURL: CONFIG.BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

interface PomInfo {
  groupId: string;
  artifactId: string;
}

export const bitbucketService = {
  getProjects: async () => {
    console.log('API Request: Getting projects');
    const response = await api.get(`/projects?limit=${CONFIG.DEFAULT_LIMIT}`);
    console.log('API Response (Projects):', response.data);
    return response.data.values;
  },

  getRepositories: async (projectKey: string) => {
    console.log('API Request: Getting repositories for project:', projectKey);
    const response = await api.get(`/repos?projectkey=${projectKey}&limit=500`);
    console.log('API Response (Repositories):', response.data);
    return response.data.values;
  },

  getDirectoryContents: async (projectKey: string, repoSlug: string, path: string, branch: string = CONFIG.DEFAULT_BRANCH) => {
    console.log('API Request: Getting directory contents', {
      projectKey,
      repoSlug,
      path,
      branch
    });
    const response = await api.get(`/projects/${projectKey}/repos/${repoSlug}/browse/${path}?limit=${CONFIG.DEFAULT_LIMIT}&at=refs/heads/${branch}`);
    console.log('API Response (Directory Contents):', response.data);
    return response.data.children?.values || [];
  },

  getFileContent: async (projectKey: string, repoSlug: string, filePath: string, branch: string = CONFIG.DEFAULT_BRANCH) => {
    console.log('API Request: Getting file content', {
      projectKey,
      repoSlug,
      filePath,
      branch
    });
    const response = await api.get(`/projects/${projectKey}/repos/${repoSlug}/browse/${filePath}?at=refs/heads/${branch}`);
    console.log('API Response (File Content):', response.data);
    return response.data.lines.map((line: { text: string }) => line.text).join('\n');
  },

  getPomInfo: async (projectKey: string, repoSlug: string, branch: string = CONFIG.DEFAULT_BRANCH): Promise<PomInfo | null> => {
    try {
      console.log('API Request: Getting pom.xml content', {
        projectKey,
        repoSlug,
        branch
      });
      const response = await api.get(`/projects/${projectKey}/repos/${repoSlug}/browse/${CONFIG.POM_PATH}?at=refs/heads/${branch}`);
      console.log('API Response (Pom Content):', response.data);
      
      const pomContent = response.data.lines.map((line: { text: string }) => line.text).join('\n');
      
      // Extract groupId and artifactId using regex
      const groupIdMatch = pomContent.match(/<groupId>(.*?)<\/groupId>/);
      const artifactIdMatch = pomContent.match(/<artifactId>(.*?)<\/artifactId>/);
      
      if (groupIdMatch && artifactIdMatch) {
        return {
          groupId: groupIdMatch[1],
          artifactId: artifactIdMatch[1]
        };
      }
      
      return null;
    } catch (error) {
      console.error('Error fetching pom.xml:', error);
      return null;
    }
  },
}; 